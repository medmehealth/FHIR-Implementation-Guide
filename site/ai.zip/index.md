# Home - MedMe Pharmacy Services Implementation Guide v0.9.21

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://fhir.medmehealth.com/pharmacy-services/ImplementationGuide/medme.fhir.pharmacy.services | *Version*:0.9.21 |
| Draft as of 2025-11-25 | *Computable Name*:MedMePharmacyServicesIG |

# MedMe Pharmacy Services Implementation Guide

## Overview

Welcome to the **MedMe Pharmacy Services Implementation Guide**. This FHIR R4 Implementation Guide provides specifications for comprehensive pharmacy services including prescription dispensing, immunizations, minor ailment treatments, and medication management services within the Canadian healthcare context.

## What's Included

This Implementation Guide defines:

* **FHIR Profiles**: Specialized profiles for pharmacy services built on Canadian Core 
* **MedMePharmacyOrganization**: Profile for pharmacy organizations with MedMe-specific identifiers and constraints
* **MedMePharmacyLocation**: Profile for pharmacy locations with required contact information and pharmacy types
* **MedMePharmacyHealthcareService**: Profile for pharmacy services with required fields and business rules
 
* **Extensions**: Custom extensions for pharmacy-specific functionality
* **Examples**: Sample resources demonstrating proper usage
* **Value Sets**: Standardized codes for pharmacy services

## Multilingual Support

This Implementation Guide supports multilingual content through FHIR primitive extensions. While the profiles don't enforce these extensions, implementers are encouraged to use them for better user experience in bilingual environments.

### Using Primitive Extensions for Translations

For fields that support multilingual content (such as `name`, `comment`, and `extraDetails` in HealthcareService), you can add French translations using primitive extensions:

```
{
  "name": "COVID-19 Vaccination Service",
  "_name": {
    "extension": [
      {
        "url": "https://hl7.org/fhir/StructureDefinition/translation",
        "extension": [
          {
            "url": "lang",
            "valueCode": "fr"
          },
          {
            "url": "content",
            "valueString": "Service de vaccination COVID-19"
          }
        ]
      }
    ]
  }
}

```

### Supported Fields for Multilingual Content

* **HealthcareService.name**: Service name
* **HealthcareService.comment**: Service description
* **HealthcareService.extraDetails**: Additional service details

### Implementation Guidelines

1. **Primary Language**: Always provide content in the primary language (English)
1. **Translation Extension**: Add`_fieldName`primitive extension for translations
1. **Language Code**: Use`fr`for French translations
1. **Content Type**: Use`valueString`for text fields,`valueMarkdown`for markdown fields

## Getting Started

To implement these profiles:

1. **Review the Profiles**: Understand the constraints and requirements
1. **Check Examples**: See sample resources in the examples section
1. **Follow Multilingual Guidelines**: Implement translations as described above
1. **Validate Resources**: Ensure your resources conform to the profiles

## Support

For questions or support with this Implementation Guide, please refer to the FHIR specification or contact the MedMe development team.

